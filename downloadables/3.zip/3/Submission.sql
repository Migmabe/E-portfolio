-- Initialization of the MySQL Codio functionality.
-- Set the database COMPANY1 as the active database.

mysql;
USE COMPANY1;

-- 1. List all Employees whose salary is between 1,000 AND 2,000.
-- Show the Employee Name, Department and Salary

SELECT EMP.ENAME AS 'Employee Name', DEPT.DNAME AS 'Department', EMP.SAL AS 'Salary'
FROM EMP
RIGHT OUTER JOIN DEPT
ON EMP.DEPTNO = DEPT.DEPTNO
WHERE SAL BETWEEN 1000 AND 2000;


-- 2. Count the number of people in department 30 who receive a salary and the number of people who receive a commission
-- Creation of 2 provisional tables to UNITE them and generate a matrix like array at the end of the task

-- First table called provisional_empno. 
-- Only for DEPT 30 members, stores the employee numbers in a single column.

CREATE TABLE provisional_empno AS
SELECT (EMPNO)
FROM DEPT
LEFT OUTER JOIN EMP
ON DEPT.DEPTNO = EMP.DEPTNO
WHERE DEPT.DEPTNO = 30;

-- Second table called provisional_comm. 
-- Only for DEPT 30 members, stores the commission values that are not NULL and strictly bigger than 0.

CREATE TABLE provisional_comm AS
SELECT (COMM)
FROM DEPT
LEFT OUTER JOIN EMP
ON DEPT.DEPTNO = EMP.DEPTNO
WHERE DEPT.DEPTNO = 30 AND EMP.COMM > 0 AND EMP.COMM IS NOT NULL;

-- Matrix like array creation using the UNION ALL statement.
-- Firstly, creation in the first select the 2 necessary columns 'Department 30' and 'Number of people'
-- Then 'People who receive a salary/commission' and the count(*) which represents the number of rows of each previously generated and filtered table,
-- are alloted into the matrix
-- *The 'AS' statements in the second selection are not needed but given for better clarity.*

SELECT 'People who receive salary' AS 'Department 30', COUNT(*) AS 'Number of people'
FROM provisional_empno
UNION ALL 
SELECT 'People who receive commission' AS 'Department 30', COUNT(*) AS 'Number of people'
FROM provisional_comm;

-- 3. Find the name and salary of employees in Dallas

-- Pretty simple JOIN and index the locations that equal to Dallas

SELECT EMP.ENAME AS 'Name', EMP.SAL AS 'Salary'
FROM EMP
JOIN DEPT ON EMP.DEPTNO = DEPT.DEPTNO
WHERE DEPT.LOC = 'Dallas';

-- 4. List all departments that do not have any employees

-- Selection, then JOIN then check the department where the employee number is null and display that one

SELECT DEPT.DEPTNO AS 'Department number', DEPT.DNAME AS 'Department name'
FROM DEPT
LEFT OUTER JOIN EMP ON EMP.DEPTNO = DEPT.DEPTNO
WHERE EMP.EMPNO IS NULL;

-- 5. List the department number and average salary of each department

-- By grouping them to department number all 3 departments are displayed.

SELECT DEPT.DEPTNO AS 'Department number', AVG(EMP.SAL) AS 'Average salary'
FROM EMP
JOIN DEPT ON EMP.DEPTNO = DEPT.DEPTNO
GROUP BY DEPT.DEPTNO;

