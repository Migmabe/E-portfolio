import Backend.API.API as API
import GUI.CLI as CLI
import Backend.server.server as server
from threading import Thread
import GUI.login_UI as login_UI
import time
import sys


# ------------FUNCTIONS FOR THREADING--------------#


class Dummy:
    def __init__(self, security=True, accountType="admin", username="nicoliflow", timeout=300):
        """
        :param timeout in SECS
        """
        self.security = security
        self.accountType = accountType
        self.username = username
        self.timeout = timeout


def main_program(settings_file):
    # First, let's start the flask server
    server_thread = Thread(target=server.ServerSettings(settings_file).app.run,
                           kwargs={"port": 5001, "use_reloader": False, "debug": True})
    server_thread.daemon = True
    server_thread.start()

    # Then, define the API object
    api = API.API_OBJECT(settings_file)
    time.sleep(1)
    # Then, use the api object to initialize the interface
    CLI.CLI(settings_file, api).main()
    server_thread.join()


if __name__ == "__main__":
    # login_UI is in charge of generating a settings file
    # UNCOMMENT WHEN API WORKING
    settings_file = login_UI.settings_file
    if settings_file is None:
        exit()
    else:
        print(repr(settings_file))
    #UNCOMMENT END
    main_program(settings_file)