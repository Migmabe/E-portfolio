import hashlib
import Backend.security.salt_generator as salt_generator


def gen_hashing(password, salt=None):
    """
    The generated passwords will be hashed using this function
    :param password == str
    :param salt | used in the check_hash function
    :return: hashed_password | salt, hashed_password
    """
    if type(password) is str:
        if salt is None:
            salt_key = salt_generator.salt
            hashed_pass = hashlib.sha256((password + f"{salt_key}").encode()).hexdigest()
            return salt_key, hashed_pass
        else:
            hashed_pass = hashlib.sha256((password + f"{salt}").encode()).hexdigest()
            return hashed_pass
    else:
        raise ValueError("Please enter a valid password, it must be a string.")


def check_hash(salt, password, stored_hash):
    """
    This function will cross check the password and compare it to the stored hash
    :param salt | retrieved from the server
    :param password | user input
    :param stored_hash | retrieved from the server
    :return True (valid) | False (passwords don't match)
    """
    if gen_hashing(password, salt) == stored_hash:
        return True
    else:
        return False