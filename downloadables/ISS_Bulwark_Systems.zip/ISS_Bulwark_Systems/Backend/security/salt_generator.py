import random

# ---------VARIABLE DEFINITION----------#

ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

# Length of the salt is set to 16, output is a string
salt = "".join([random.choice(ALPHABET) for i in range(0, 16)])
