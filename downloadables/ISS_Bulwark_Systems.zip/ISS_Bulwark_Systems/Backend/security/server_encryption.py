"""This file will decode the input from the API. The key exchange mechanism is the one proposed by Diffie-Hellman where
a public key is exchanged and this one decoded using their own private keys. Two line-equations are used to simulate this
Input X output Y"""

import random
import math


# -------------VARIABLES------------#
class Line:
    def __init__(self, m, n):
        self.m = m
        self.n = n

    def process_input(self, x_input):
        """Convert X-coord into Y_coord. Returns Y-coord. Used to decrypt"""
        return self.m * x_input + self.n  # self is the opposite line object

    def output(self):
        """Generate X-coord."""
        y_coord = random.randint(0, 200)  # range in which both lines yield positive values when exchanging
        return (y_coord - self.n) / self.m

    def exchanger(self, client):
        """Issuer and client represent either the API or the server, they can take each other's position as argument
        depending on the case. Client is a LINE OBJECT"""
        public_key = self.output()
        private_key = client.process_input(public_key)
        return public_key, private_key


# ---------LINE OBJECTS--------#

API_line = Line(-1, 500)
SERVER_line = Line(0.5, 4)

# -------------MAPPING--------------#

mapping = {0: 'A', 1: 'w', 2: 'W', 3: 'S', 4: 'J', 5: 'U', 6: '3', 7: 'X', 8: 'm', 9: 'H', 10: 'Q', 11: 'x', 12: '8',
           13: '6', 14: '2', 15: 's', 16: 'k', 17: '9', 18: 'B', 19: 'C', 20: 'E', 21: 'L', 22: 'M', 23: '0', 24: '4',
           25: 'o', 26: 'h', 27: 'R', 28: 'j', 29: 'P', 30: 'K', 31: 'T', 32: 'd', 33: 'D', 34: 'f', 35: 'v', 36: '7',
           37: 't', 38: 'r', 39: 'e', 40: 'b', 41: 'z', 42: 'G', 43: 'i', 44: 'Y', 45: 'V', 46: 'F', 47: 'c', 48: 'I',
           49: 'l', 50: '5', 51: 'u', 52: 'g', 53: '1', 54: 'Z', 55: 'y', 56: 'a', 57: 'N', 58: 'q', 59: 'p', 60: 'n',
           61: 'O', 62: ' ', 63: '.', 64: ')', 65: '(', 66: '^', 67: '!', 68: ';', 69: ':', 70: ']', 71: '[', 72: '–',
           73: '~', 74: '$', 75: '@', 76: '_'}


# -------------FUNCTIONS-------------#
def reverse_dict(dictionary):
    """Reverses dictionaries"""
    empty = {}
    for key, value in dictionary.items():
        empty[value] = key
    return empty


def filter(value):
    """This function will keep the key shift values within the dictionary's length, in this case 63."""
    if value > 76:
        shift = value % 76
        return shift
    else:
        return value


def encrypter(message, issuer: Line, client: Line):
    """
    :param message: str
    :param issuer either API_line or SERVER_line
    :param client either API_line or SERVER_line
    :return: encrypted message and public key
    """
    if type(message) is str:
        keys = issuer.exchanger(client)
        public_key = keys[0]
        private_key = keys[1]
        encrypted_str = ""
        for _ in "".join(message):
            pointer = reverse_dict(mapping)[_] + math.trunc(private_key) % 76
            if pointer > 76:
                pointer = pointer - 76
            encrypted_str += mapping[pointer]
        return encrypted_str, public_key
    else:
        raise TypeError("Message must be a string")


def decrypter(cipher, public_key, receiver: Line):
    """
    :param public_key: int
    :param cipher = encrypted message str
    :param receiver = Line object either server or API
    :return: original message
    """
    if type(cipher) is str:
        original_message = ""
        private_key = receiver.process_input(public_key)
        for _ in cipher:
            pointer = reverse_dict(mapping)[_] - math.trunc(private_key) % 76
            if pointer < 0:
                pointer = 76 - abs(pointer)
            original_message += mapping[pointer]
        return original_message
    else:
        raise ValueError("Cipher message must be a string.")

