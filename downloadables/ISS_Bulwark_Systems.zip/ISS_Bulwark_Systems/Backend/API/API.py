import requests
import Backend.security.server_encryption as server_encryption


# -----------ENCRYPTION ENGINE-----------#

def json_handler(operation: str, jsondata: dict):
    """This function will apply the encryption algorithm to the json data, so the dict ciphered and
    deciphered accordingly
    :param operation == either "encrypt" or "decrypt"
    :param jsondata == dictionary with the request
    :returns either encrypted_json and public key OR decrypted_json
    """
    if operation == "encrypt" or operation == "decrypt":
        if operation == "encrypt":
            encrypted_json = {}
            for _ in jsondata.keys():
                # The new encrypted dict keys will be paired up to a tuple with the encrypted str and the key
                encrypted_json[_] = server_encryption.encrypter(jsondata[_], server_encryption.API_line,
                                                                server_encryption.SERVER_line)
            return encrypted_json
        elif operation == "decrypt":
            decrypted_json = {}
            for _ in jsondata.keys():
                # The json dict will be decrypted using the encrypted str and public key passed in as a tuple
                cipher, key = jsondata[_]
                decrypted_json[_] = server_encryption.decrypter(cipher, float(key), server_encryption.API_line)
            return decrypted_json
    else:
        raise TypeError('The operation must either be "encrypt" or "decrypt"')


def jsonify_adapter(db_response: list, operation=None):
    """
    :param operation can be None | "encrypt" | "decrypt"
    :param db response is a list of objects
    :return list of dictionaries
    """
    if operation is None:
        if type(db_response) != list:
            user = {
                "name": db_response.name,
                "username": db_response.username,
                "accountType": db_response.accountType
            }
            return [user]
        else:
            collect = []
            for _ in db_response:
                user = {
                    "name": _.name,
                    "username": _.username,
                    "accountType": _.accountType
                }
                collect.append(user)
            return collect
    elif operation == "encrypt":
        if type(db_response) != list:
            user = {
                "name": db_response.name,
                "username": db_response.username,
                "accountType": db_response.accountType
            }
            return [json_handler("encrypt", user)]
        else:
            collect = []
            for _ in db_response:
                user = {
                    "name": _.name,
                    "username": _.username,
                    "accountType": _.accountType
                }
                collect.append(json_handler("encrypt", user))
            return collect
    elif operation == "decrypt":
        collect = []
        for _ in db_response:
            collect.append(json_handler("decrypt", _))
        return collect


def jsonify_adapter_admin(db_response: list, operation=None):
    """
    same as before but displays password and salt
    """
    if operation is None:
        if type(db_response) != list:
            user = {
                "name": db_response.name,
                "username": db_response.username,
                "salt": db_response.salt,
                "paswword": db_response.password,
                "accountType": db_response.accountType
            }
            return [user]
        else:
            collect = []
            for _ in db_response:
                user = {
                    "name": _.name,
                    "username": _.username,
                    "salt": _.salt,
                    "password": _.password,
                    "accountType": _.accountType
                }
                collect.append(user)
            return collect
    elif operation == "encrypt":
        if type(db_response) != list:
            user = {
                "name": db_response.name,
                "username": db_response.username,
                "salt": db_response.salt,
                "password": db_response.password,
                "accountType": db_response.accountType
            }
            return [json_handler("encrypt", user)]
        else:
            collect = []
            for _ in db_response:
                user = {
                    "name": _.name,
                    "username": _.username,
                    "salt": _.salt,
                    "password": _.password,
                    "accountType": _.accountType
                }
                collect.append(json_handler("encrypt", user))
            return collect
    elif operation == "decrypt":
        collect = []
        for _ in db_response:
            collect.append(json_handler("decrypt", _))
        return collect


# -------------END--------------------#


class API_OBJECT:

    def __init__(self, security_file):
        """
        :param add settings file
        """
        #self.security = settings_file.security put visible when designed the API
        # ---------------DELETE AFTER DESIGNING THIS-----------#
        self.security = security_file.security
        self.accountType = security_file.accountType

    def post(self, data: dict):
        """
        :param data must be a dictionary with all 5 attributes
        """
        endpoint = "http://127.0.0.1:5001/add/user"
        if self.security:
            print(f"Requesting create on endpoint {endpoint}")
            response = requests.post(endpoint, json=data)
            if response.status_code == 200:
                print("POST request successfully sent to server.")
                print(response.json())
                return response.json(), response.status_code
            else:
                print(response.json())
                print(f"POST request failed with status code: {response.status_code}")
        else:
            print(f"Requesting create on endpoint {endpoint}")
            API_key = server_encryption.encrypter("myAPIkey8)", server_encryption.API_line,
                                                  server_encryption.SERVER_line)
            response = requests.post(endpoint, json=json_handler("encrypt", data), headers={"Authorization": f"{API_key[0]},{API_key[1]}"})
            if response.status_code == 200:
                print("POST request successfully sent to server.")
                print(response.json())
                return response.json(), response.status_code
            else:
                print(response.json())
                print(f"POST request failed with status code: {response.status_code}")

    def get(self, attribute: str, value: str):
        if self.security:
            endpoint = f"http://127.0.0.1:5001/users/{attribute}?value={value}"
            print(f"Requesting data from endpoint {endpoint}")
            response = requests.get(endpoint)
            if response.status_code == 200:
                print("GET request successfully sent to server.")
                k = 1
                for item in response.json():
                    print(f"User {k}")
                    k += 1
                    for key, value in item.items():
                        print(f"\t{key}: {value}")
                return response.json(), response.status_code
            else:
                print(response.json())
                print(f"GET request failed with status code: {response.status_code}. Not found.")
        else:
            cipher_value = server_encryption.encrypter(value, server_encryption.API_line, server_encryption.SERVER_line)
            new_value = f"{cipher_value[0]},{cipher_value[1]}"
            endpoint = f"http://127.0.0.1:5001/users/{attribute}?value={new_value}"
            print(f"Requesting data from endpoint {endpoint}")
            # Generate the API key in the header
            API_key = server_encryption.encrypter("myAPIkey8)", server_encryption.API_line, server_encryption.SERVER_line)
            response = requests.get(endpoint, headers={"Authorization": f"{API_key[0]},{API_key[1]}"})
            if response.status_code == 200:
                print("GET request successfully sent to server.")
                k = 1
                if self.accountType == "admin":
                    for item in jsonify_adapter_admin(response.json(), "decrypt"):
                        print(f"User {k}")
                        k += 1
                        for key, value in item.items():
                            print(f"\t{key}: {value}")
                    return jsonify_adapter_admin(response.json(), "decrypt"), response.status_code
                else:
                    for item in jsonify_adapter(response.json(), "decrypt"):
                        print(f"User {k}")
                        k += 1
                        for key, value in item.items():
                            print(f"\t{key}: {value}")
                    return response.json()
            else:
                print(response.json())
                print(f"GET request failed with status code: {response.status_code}. Not found.")

    def get_logons(self, setting, **kwargs):

        if setting == "username":
            endpoint = f"http://127.0.0.1:5001/logon/username?value={kwargs["username"]}"
            print(f"Requesting data from endpoint {endpoint}")
            response = requests.get(endpoint)
            if response.status_code == 200:
                print("GET request successfully sent to server.")
                k = 1
                for item in response.json():
                    print(f"Entry {k}")
                    k += 1
                    for key, value in item.items():
                        print(f"\t{key}: {value}")
                return response.json()
            else:
                print(response.json())
                print(f"GET request failed with status code: {response.status_code}. Not found."), 404
        elif setting == "all":
            endpoint = f"http://127.0.0.1:5001/logon/all"
            print(f"Requesting data from endpoint {endpoint}")
            response = requests.get(endpoint)
            if response.status_code == 200:
                print("GET request successfully sent to server.")
                k = 1
                for item in response.json():
                    print(f"Entry {k}")
                    k += 1
                    for key, value in item.items():
                        print(f"\t{key}: {value}")
                return response.json()
            else:
                print(response.json())
                print(f"GET request failed with status code: {response.status_code}. Not found."), 404

    def patch(self, username: str, value: dict):
        """
        :param new_value must be a dictionary formatted like {"attribute": "new value"} | {"name": "pepito"}
        """
        if self.security:
            endpoint = f"http://127.0.0.1:5001/modify/{username}"
            print(f"Requesting patch to endpoint {endpoint}")
            response = requests.patch(endpoint, json=value)
        else:
            cipher_username = server_encryption.encrypter(username, server_encryption.API_line,
                                                          server_encryption.SERVER_line)
            new_username = f"{cipher_username[0]},{cipher_username[1]}"
            cipher_value = json_handler("encrypt", value)
            endpoint = f"http://127.0.0.1:5001/modify/{new_username}"
            print(f"Requesting patch to endpoint {endpoint}")
            API_key = server_encryption.encrypter("myAPIkey8)", server_encryption.API_line,
                                                  server_encryption.SERVER_line)
            response = requests.patch(endpoint, headers={"Authorization": f"{API_key[0]},{API_key[1]}"}, json=cipher_value)
        if response.status_code == 200:
            print("PATCH request successfully sent to server.")
            print(response.json())
            return response.json(), response.status_code
        else:
            print(response.json())
            print(f"PATCH request failed with status code: {response.status_code}. Not found.")

    def delete(self, username):
        if self.security:
            endpoint = f"http://127.0.0.1:5001/delete/{username}"
            print(f"Requesting delete from endpoint {endpoint}")
            response = requests.delete(endpoint)
        else:
            cipher_username = server_encryption.encrypter(username, server_encryption.API_line,
                                                          server_encryption.SERVER_line)
            new_username = f"{cipher_username[0]},{cipher_username[1]}"
            endpoint = f"http://127.0.0.1:5001/delete/{new_username}"
            print(f"Requesting delete from endpoint {endpoint}")
            API_key = server_encryption.encrypter("myAPIkey8)", server_encryption.API_line,
                                                  server_encryption.SERVER_line)
            response = requests.delete(endpoint, headers={"Authorization": f"{API_key[0]},{API_key[1]}"})

        if response.status_code == 200:
            print("DELETE request successfully sent to server.")
            data = response.json()
            print(data)
            return data, 200
        elif response.status_code == 202:
            print("DELETE request successfully sent to server.")
            data = response.json()
            print(data)
            print("\nExiting the system...")
        else:
            print(response.json())
            print(f"DELETE request failed with status code: {response.status_code}. Not found.")


# -----------RUN BLOCK------#
