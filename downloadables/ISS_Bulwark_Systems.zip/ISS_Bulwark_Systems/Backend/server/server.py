from flask import Flask, jsonify, request
import Backend.security.server_encryption as server_encryption
import Backend.server.db_nav as db_nav
import Backend.security.hashing as hashing
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from GUI import password_generator, password_checker


# -----------IMPORT SECURITY SETTING-------#

# ------------FUNCTIONS-------------#

def jsonify_adapter(db_response: list, operation=None):
    """
    :param operation can be None | "encrypt" | "decrypt"
    :param db response is a list of objects
    """
    if operation is None:
        if type(db_response) != list:
            user = {
                "name": db_response.name,
                "username": db_response.username,
                "accountType": db_response.accountType
            }
            return [user]
        else:
            collect = []
            for _ in db_response:
                user = {
                    "name": _.name,
                    "username": _.username,
                    "accountType": _.accountType
                }
                collect.append(user)
            return collect
    elif operation == "encrypt":
        if type(db_response) != list:
            user = {
                "name": db_response.name,
                "username": db_response.username,
                "accountType": db_response.accountType
            }
            return [json_handler("encrypt", user)]
        else:
            collect = []
            for _ in db_response:
                user = {
                    "name": _.name,
                    "username": _.username,
                    "accountType": _.accountType
                }
                collect.append(json_handler("encrypt", user))
            return collect
    elif operation == "decrypt":
        collect = []
        for _ in db_response:
            collect.append(json_handler("decrypt", _))
        return collect


def jsonify_adapter_admin(db_response: list, operation=None):
    """
    same as before but displays password and salt
    """
    if operation is None:
        if type(db_response) != list:
            user = {
                "name": db_response.name,
                "username": db_response.username,
                "salt": db_response.salt,
                "paswword": db_response.password,
                "accountType": db_response.accountType
            }
            return [user]
        else:
            collect = []
            for _ in db_response:
                user = {
                    "name": _.name,
                    "username": _.username,
                    "salt": _.salt,
                    "password": _.password,
                    "accountType": _.accountType
                }
                collect.append(user)
            return collect
    elif operation == "encrypt":
        if type(db_response) != list:
            user = {
                "name": db_response.name,
                "username": db_response.username,
                "salt": db_response.salt,
                "password": db_response.password,
                "accountType": db_response.accountType
            }
            return [json_handler("encrypt", user)]
        else:
            collect = []
            for _ in db_response:
                user = {
                    "name": _.name,
                    "username": _.username,
                    "salt": _.salt,
                    "password": _.password,
                    "accountType": _.accountType
                }
                collect.append(json_handler("encrypt", user))
            return collect
    elif operation == "decrypt":
        collect = []
        for _ in db_response:
            collect.append(json_handler("decrypt", _))
        return collect


def injection_row_converter(sql_entry: list):
    """:param sql_entry is a list of rows
    :return list of dictionaries"""
    output = []
    for _ in sql_entry:
        entry = {
            "name": _[1],
            "username": _[2],
            "salt": _[3],
            "password": _[4],
            "accountType": _[5]
        }
        output.append(entry)
    return output


# -----------END--------------------#


# -------------JSON ENCRYPTION--------#
# Same function as in API end but adapted to server
def json_handler(operation: str, jsondata: dict):
    """This function will apply the encryption algorithm to the json data, so the dict ciphered and
    deciphered accordingly
    :param operation == either "encrypt" or "decrypt"
    :param jsondata == dictionary with the request
    :returns either encrypted_json and public key OR decrypted_json
    """
    if type(operation) is str:
        if operation == "encrypt":
            encrypted_json = {}
            for _ in jsondata.keys():
                # The new encrypted dict keys will be paired up to a tuple with the encrypted str and the key
                encrypted_json[_] = server_encryption.encrypter(jsondata[_], server_encryption.SERVER_line,
                                                                server_encryption.API_line)
            return encrypted_json
        elif operation == "decrypt":
            decrypted_json = {}
            for _ in jsondata.keys():
                # The json dict will be decrypted using the encrypted str and public key passed in as a tuple
                cipher, key = jsondata[_]
                decrypted_json[_] = server_encryption.decrypter(cipher, float(key), server_encryption.SERVER_line)
            return decrypted_json
    else:
        raise TypeError('The operation must either be "encrypt" or "decrypt"')


# ---------END----------------#


class ServerSettings:
    def __init__(self, settings_file):
        self.security = settings_file.security
        self.accountType = settings_file.accountType
        self.username = settings_file.username
        self.app = Flask(__name__)
        self.DB = db_nav.CRUD()
        self.limiter = Limiter(key_func=get_remote_address, app=self.app, default_limits=["800000 per second"])  # make it override when security setting is True
        # Initialize the routes
        self.setup_routes()

    def setup_routes(self):
        # This function will run before every request, filtering requests out when security is ON (security == False)
        @self.app.before_request
        # Limiting it to 50 a second, as per the amount of users than can use the server simultaneously.
        def filter_request():
            if self.security or request.path.startswith("/logon"):
                # Skip authorization when admin requests all logons and when security is off
                pass
            else:
                try:
                    with self.limiter.limit("50 per second", override_defaults=not self.security):
                        cipher, key = request.headers.get("Authorization").split(",")
                        original_value = server_encryption.decrypter(cipher, float(key),
                                                                     server_encryption.SERVER_line)
                        if original_value == "myAPIkey8)":
                            pass
                        else:
                            return jsonify({"Forbidden": "Invalid API key"}), 403
                except:
                    return jsonify({"Forbidden": "Invalid API key or exceeded number of requests."}), 403

        @self.app.route(
            '/users/<string:attribute>',
            methods=["GET"])  # example http://127.0.0.1:5001/users/username?value=miguelin
        def user_locator(attribute):
            """
            :param attribute = "username" | "name" | "accountType" |
            """
            if request.method == "GET":
                flask_query = request.args.get("value")
                try:
                    # Now handle the request by selecting the search method
                    if attribute == "username":
                        if self.security:
                            entry = self.DB.read_injection(username=flask_query)
                            if len(entry) > 0:
                                self.DB.create(username=self.username,
                                               operation=f"look for users by {attribute} = {flask_query}")
                                json_object = jsonify(injection_row_converter(entry)), 200
                                return json_object
                            else:
                                return jsonify({"Error": "User not found in database"}), 404
                        elif self.security is False and self.accountType != "admin":
                            try:
                                cipher, key = flask_query.split(",")
                                original_value = server_encryption.decrypter(cipher, float(key),
                                                                             server_encryption.SERVER_line)
                                entry = self.DB.read("users", username=original_value)
                                if entry is not None:
                                    self.DB.create(username=self.username,
                                                   operation=f"look for users by {attribute} = {original_value}")
                                    json_object = jsonify(jsonify_adapter(entry, "encrypt"))
                                    return json_object
                                else:
                                    self.DB.create(username=self.username,
                                                   operation=f"look for users by {attribute} = {original_value} not successful")
                                    return jsonify({"Error": "User not found"}), 404
                            except:
                                return jsonify({"Error": "It is likely you are not a verified API"}), 403
                        elif self.security is False and self.accountType == "admin":
                            try:
                                cipher, key = flask_query.split(",")
                                original_value = server_encryption.decrypter(cipher, float(key),
                                                                             server_encryption.SERVER_line)
                                entry = self.DB.read("users", username=original_value)
                                if entry is not None:
                                    self.DB.create(username=self.username,
                                                   operation=f"look for users by {attribute} = {original_value}")
                                    json_object = jsonify(jsonify_adapter_admin(entry, "encrypt"))
                                    return json_object
                                else:
                                    self.DB.create(username=self.username,
                                                   operation=f"look for users by {attribute} = {original_value} not successful")
                                    return jsonify({"Error": "User not found"})
                            except:
                                return jsonify({"Error": "It is likely you are not a verified API"}), 403

                    elif attribute == "name":
                        if self.security:
                            entry = self.DB.read_injection(name=flask_query)
                            if len(entry) > 0:
                                self.DB.create(username=self.username,
                                               operation=f"look for users by {attribute} = {flask_query}")
                                json_object = jsonify(injection_row_converter(entry)), 200
                                return json_object
                            else:
                                return jsonify({"Error": "User not found in database"}), 404
                        elif self.security is False and self.accountType != "admin":
                            try:
                                cipher, key = flask_query.split(",")
                                original_value = server_encryption.decrypter(cipher, float(key),
                                                                             server_encryption.SERVER_line)
                                entry = self.DB.read("users", name=original_value)
                                if len(entry) > 0:
                                    self.DB.create(username=self.username,
                                                   operation=f"look for users by {attribute} = {original_value}")
                                    json_object = jsonify(jsonify_adapter(entry, "encrypt"))
                                    return json_object
                                else:
                                    return jsonify({"Error": "User not found in database"}), 404
                            except:
                                return jsonify({"Error": "It is likely you are not a verified API"}), 403
                        elif self.security is False and self.accountType == "admin":
                            try:
                                cipher, key = flask_query.split(",")
                                original_value = server_encryption.decrypter(cipher, float(key),
                                                                             server_encryption.SERVER_line)
                                entry = self.DB.read("users", name=original_value)
                                if len(entry) > 0:
                                    self.DB.create(username=self.username,
                                                   operation=f"look for users by {attribute} = {original_value}")
                                    json_object = jsonify(jsonify_adapter_admin(entry, "encrypt"))
                                    return json_object
                                else:
                                    return jsonify({"Error": "User not found in database"}), 404
                            except:
                                return jsonify({"Error": "It is likely you are not a verified API"}), 403

                    elif attribute == "accountType":
                        if self.security:
                            entry = self.DB.read_injection(accountType=flask_query)
                            if len(entry) > 0:
                                self.DB.create(username=self.username,
                                               operation=f"look for users by {attribute} = {flask_query}")
                                json_object = jsonify(injection_row_converter(entry)), 200
                                return json_object
                            else:
                                return jsonify({"Error": "User not found in database"}), 404
                        elif self.security is False and self.accountType != "admin":
                            try:
                                cipher, key = flask_query.split(",")
                                original_value = server_encryption.decrypter(cipher, float(key),
                                                                             server_encryption.SERVER_line)
                                entry = self.DB.read("users", accountType=original_value)
                                if len(entry) > 0:
                                    self.DB.create(username=self.username,
                                                   operation=f"look for users by {attribute} = {original_value}")
                                    json_object = jsonify(jsonify_adapter(entry, "encrypt"))
                                    return json_object
                                else:
                                    return jsonify({"Error": "User not found in database"}), 404
                            except:
                                return jsonify({"Error": "It is likely you are not a verified API"}), 403
                        elif self.security is False and self.accountType == "admin":
                            try:
                                cipher, key = flask_query.split(",")
                                original_value = server_encryption.decrypter(cipher, float(key),
                                                                             server_encryption.SERVER_line)
                                entry = self.DB.read("users", accountType=original_value)
                                if len(entry) > 0:
                                    self.DB.create(username=self.username,
                                                   operation=f"look for users by {attribute} = {original_value}")
                                    json_object = jsonify(jsonify_adapter_admin(entry, "encrypt"))
                                    return json_object
                                else:
                                    return jsonify({"Error": "User not found in database"}), 404
                            except:
                                return jsonify({"Error": "It is likely you are not a verified API"}), 403
                    else:
                        return jsonify({"Error": "Search attribute not valid"}), 404
                except:
                    return jsonify({"Error": "Attribute not found"}), 404

        @self.app.route("/add/user", methods=["POST"])  # example http://127.0.0.1:5001/add/user
        def user_creator():
            """
            This function will post data from the API to the server
            """
            if self.security:
                data = request.json  # this is a dictionary
                try:
                    self.DB.create(name=data["name"], password=data["password"], accountType=data["accountType"],
                                   salt=data["salt"],
                                   username=data["username"])
                    self.DB.create(username=self.username, operation=f"create new user {data['username']}")
                    return jsonify(response={"success": f"Successfully added {data["name"]} to the database."}), 200
                except:
                    return jsonify({"Error": "User already in database. User not created"}), 403
            elif self.security is False and self.accountType == "admin":
                try:
                    data = request.json
                    new_data = json_handler("decrypt", data)
                    try:
                        self.DB.create(name=new_data["name"], password=new_data["password"],
                                       accountType=new_data["accountType"],
                                       salt=new_data["salt"],
                                       username=new_data["username"])
                        self.DB.create(username=self.username, operation=f"create new user {new_data['username']}")
                        return jsonify(
                            response={"Success": f"Successfully added {new_data["name"]} to the database."}), 200
                    except:
                        return jsonify({"Error": "User already in database. User not created"}), 403
                except:
                    return jsonify({"Error": "It is likely you are not a verified API"}), 403
            else:
                return jsonify({"Error": "Operation not allowed"}), 403

        @self.app.route("/modify/<string:username>",
                        methods=["PATCH"])  # Example http://127.0.0.1:5001/modify/juli
        def user_modifier(username):
            """
            This function will modify users, only when security is True or ADMIN is doing the operation
            """
            if request.method == "PATCH":
                update_data = request.json.items()  # this is a dictionary sent by the API
                # if the try block fails it is likely that the API requesting from the server is not verified,
                # as it does not know the proper formatting
                try:
                    for key, value in update_data:
                        attribute = key
                        data = value
                        if self.security:
                            if attribute == "name":
                                operation = self.DB.update(username, name=data)
                                if operation:
                                    self.DB.create(username=self.username, operation=f"modify {username}'s {attribute}")
                                    return jsonify({"Success": f"{attribute} changed for user {username}"}), 200
                                else:
                                    return jsonify({"Error": f"User {username} not found in database"}), 404
                            elif attribute == "password":
                                salt = self.DB.read("users", username=username, salt=True)
                                operation = self.DB.update(username, password=hashing.gen_hashing(data, salt))
                                if operation:
                                    self.DB.create(username=self.username, operation=f"modify {username}'s {attribute}")
                                    return jsonify({"Success": f"{attribute} changed for user {username}"}), 200
                                else:
                                    return jsonify({"Error": f"User {username} not found in database"}), 404
                            elif attribute == "accountType":
                                operation = self.DB.update(username, accountType=data)
                                if operation:
                                    self.DB.create(username=self.username, operation=f"modify {username}'s {attribute}")
                                    return jsonify({"Success": f"{attribute} changed for user {username}"}), 200
                                else:
                                    return jsonify({"Error": f"User {username} not found in database"}), 404
                            elif attribute == "username":
                                operation = self.DB.update(username, username=data)
                                if operation:
                                    self.DB.create(username=self.username, operation=f"modify {username}'s {attribute}")
                                    return jsonify({"Success": f"{attribute} changed for user {username}"}), 200
                                else:
                                    return jsonify({"Error": f"User {username} not found in database"}), 404
                            else:
                                return jsonify({"Error": "Operation does not exist"}), 404
                        elif self.security is False and self.accountType == "admin":
                            # data sent by the API
                            cipher = data[0]
                            key = data[1]
                            original_message = server_encryption.decrypter(cipher, float(key),
                                                                           server_encryption.SERVER_line)
                            cipher, key = username.split(",")
                            original_username = server_encryption.decrypter(cipher, float(key),
                                                                            server_encryption.SERVER_line)
                            if attribute == "name":
                                operation = self.DB.update(original_username, name=original_message)
                                if operation:
                                    self.DB.create(username=self.username,
                                                   operation=f"modify {original_username}'s name")
                                    return jsonify(
                                        {"Success": f"{attribute} changed for user {original_username}"}), 200
                                else:
                                    return jsonify({"Error": f"User {original_username} not found in database"}), 404
                            elif attribute == "username":
                                operation = self.DB.update(original_username, username=original_message)
                                if operation:
                                    self.DB.create(username=self.username,
                                                   operation=f"modify {original_username}'s username")
                                    return jsonify(
                                        {"Success": f"{attribute} changed for user {original_username}"}), 200
                                else:
                                    return jsonify({"Error": f"User {original_username} not found in database"}), 404
                            elif attribute == "accountType":
                                operation = self.DB.update(original_username, accountType=original_message)
                                if operation:
                                    self.DB.create(username=self.username,
                                                   operation=f"modify {original_username}'s accountType")
                                    return jsonify(
                                        {"Success": f"{attribute} changed for user {original_username}"}), 200
                                else:
                                    return jsonify({"Error": f"User {original_username} not found in database"}), 404
                            elif attribute == "password":
                                check = password_checker.interface_password_checker(password_generator,
                                                                                    password=original_message)
                                if check[1]:
                                    salt = self.DB.read("users", username=original_username, salt=True)
                                    operation = self.DB.update(original_username,
                                                               password=hashing.gen_hashing(original_message, salt))
                                    if operation:
                                        self.DB.create(username=self.username,
                                                       operation=f"modify {original_username}'s password")
                                        return jsonify(
                                            {"Success": f"{attribute} changed for user {original_username}"}), 200
                                    else:
                                        return jsonify(
                                            {"Error": f"User {original_username} not found in database"}), 404
                                else:
                                    for _ in check[0]:
                                        print(_)
                                    return jsonify(
                                        {
                                            "Error": f"Password {original_message} does not comply with the password rules"}), 404
                            else:
                                return jsonify({"Error": "Operation does not exist"}), 404

                        elif self.security is False and self.accountType != "admin":
                            # data sent by the API
                            cipher = data[0]
                            key = data[1]
                            original_message = server_encryption.decrypter(cipher, float(key),
                                                                           server_encryption.SERVER_line)
                            cipher, key = username.split(",")
                            original_username = server_encryption.decrypter(cipher, float(key),
                                                                            server_encryption.SERVER_line)
                            if attribute == "name":
                                if self.username == original_username:
                                    operation = self.DB.update(original_username, name=original_message)
                                    if operation:
                                        self.DB.create(username=self.username,
                                                       operation=f"modify {original_username}'s {attribute}")
                                        return jsonify(
                                            {"Success": f"{attribute} changed for user {original_username}"}), 200
                                    else:
                                        return jsonify(
                                            {"Error": f"User {original_username} not found in database"}), 404
                                else:
                                    return jsonify(
                                        {"Error": "You do not have enough permissions to perform the operation"}), 403
                            elif attribute == "username":
                                if self.username == original_username:
                                    operation = self.DB.update(original_username, username=original_message)
                                    if operation:
                                        self.DB.create(username=self.username,
                                                       operation=f"modify {original_username}'s {attribute}")
                                        return jsonify(
                                            {"Success": f"{attribute} changed for user {original_username}"}), 200
                                    else:
                                        return jsonify(
                                            {"Error": f"User {original_username} not found in database"}), 404
                                else:
                                    return jsonify(
                                        {"Error": "You do not have enough permissions to perform the operation"}), 403
                            elif attribute == "password":
                                if self.username == original_username:
                                    check = password_checker.interface_password_checker(password_generator,
                                                                                        password=original_message)
                                    if check[1]:
                                        salt = self.DB.read("users", username=original_username, salt=True)
                                        operation = self.DB.update(original_username,
                                                                   password=hashing.gen_hashing(original_message, salt))
                                        if operation:
                                            self.DB.create(username=self.username,
                                                           operation=f"modify {original_username}'s {attribute}")
                                            return jsonify(
                                                {"Success": f"{attribute} changed for user {original_username}"}), 200
                                        else:
                                            return jsonify(
                                                {"Error": f"User {original_username} not found in database"}), 404
                                    else:
                                        for _ in check[0]:
                                            print(_)
                                        return jsonify(
                                            {
                                                "Error": f"Password {original_message} does not comply with the password rules"}), 400
                                else:
                                    return jsonify(
                                        {"Error": "You do not have enough permissions to perform the operation"}), 403
                            else:
                                return jsonify({"Error": "Operation does not exist"}), 404
                except:
                    return jsonify({"Error": "It is likely you are not a verified API"}), 403
            else:
                return jsonify({"Error": "PATCH request not processed"}), 500

        @self.app.route("/delete/<string:username>",
                        methods=["DELETE"])  # Example http://127.0.0.1:5001/delete/miguelin
        def user_delete(username):
            """username directly passed in the html header"""
            if request.method == "DELETE":
                if self.security:
                    delete_operator = self.DB.deletion(username)
                    if type(delete_operator) is tuple:
                        return jsonify(delete_operator)
                    else:
                        self.DB.create(username=self.username, operation=f"delete user {username}")
                        return jsonify({f"Success": f"User {username} has been deleted"}), 200
                elif self.security is False and self.accountType == "admin":
                    cipher, key = username.split(",")
                    original_message = server_encryption.decrypter(cipher, float(key), server_encryption.SERVER_line)
                    delete_operator = self.DB.deletion(original_message)
                    if type(delete_operator) is tuple:
                        return jsonify(delete_operator)
                    else:
                        self.DB.create(username=self.username, operation=f"delete user {original_message}")
                        return jsonify({f"Success": f"User {original_message} has been deleted"}), 200
                elif self.security is False and self.accountType != "admin":
                    cipher, key = username.split(",")
                    original_message = server_encryption.decrypter(cipher, float(key), server_encryption.SERVER_line)
                    if self.username == original_message:
                        delete_operator = self.DB.deletion(original_message)
                        if type(delete_operator) is tuple:
                            return jsonify(delete_operator)
                        else:
                            self.DB.create(username=self.username, operation=f"delete user {original_message}")
                            return jsonify({f"Success": f"Your user was deleted"}), 202
                    else:
                        return jsonify({"Error": "Operation forbidden"}), 403

        @self.app.route("/logon/<setting>", methods=["GET"])
        def system_logons(setting):
            if self.security or self.accountType == "admin":
                if setting == "all":
                    entry = self.DB.read_all("logon")
                    output_dict = []
                    for _ in entry:
                        user = {
                            "username": _.username,
                            "operation": _.operation,
                            "time": _.time
                        }
                        output_dict.append(user)
                    json_object = jsonify(output_dict), 200
                    return json_object
                elif setting == "username":
                    flask_query = request.args.get("value")
                    entry = self.DB.read("logon", username=flask_query)
                    output_dict = []
                    for _ in entry:
                        user = {
                            "username": _.username,
                            "operation": _.operation,
                            "time": _.time
                        }
                        output_dict.append(user)
                    json_object = jsonify(output_dict), 200
                    return json_object
            else:
                return jsonify({"Error": "You do not have the required permissions"}), 403

# -----------END-----------------#
