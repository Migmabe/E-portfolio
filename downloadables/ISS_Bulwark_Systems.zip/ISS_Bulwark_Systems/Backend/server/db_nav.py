from Backend.server import database as database
import datetime
from sqlalchemy import text


class Interface():
    def __init__(self, database_app=database.app, database_db=database.db):
        self.app = database_app
        self.db = database_db


class CRUD(Interface):

    def create(self, **kwargs):

        """
        :param kwargs: USER(name, username, password, accountType) || SYSTEMLOGON(username)
        :return: Create entries in db
        """
        if "name" in kwargs:
            with self.app.app_context():
                self.db.session.add(database.Users(name=kwargs["name"], username=kwargs["username"],
                                                   password=kwargs["password"], accountType=kwargs["accountType"],
                                                   salt=kwargs["salt"]))
                self.db.session.commit()
        elif "username" in kwargs:
            with self.app.app_context():
                self.db.session.add(database.SystemLogon(username=kwargs["username"], operation=kwargs["operation"],
                                                         time=datetime.datetime.now()))
                self.db.session.commit()

    def read(self, db_selection, **kwargs):

        """
        :param db_selection: either "users" or "logon" to retrieve data from one db or the other
        :param kwargs: USER(name, username, accountType) || SYSTEMLOGON(username)
        :return: Read entries in db
        """
        if db_selection == "users":
            if "salt" in kwargs:
                with self.app.app_context():
                    entry = self.db.session.execute(self.db.select(database.Users.salt).
                                                    where(database.Users.username == kwargs["username"])).scalar()
                    return entry  # returns an object with attributes
            elif "username" in kwargs:
                # Username is a unique attribute of every user, so cannot find more than one hence scalar.
                # Server does the handling
                with self.app.app_context():
                    entry = self.db.session.execute(self.db.select(database.Users).
                                                    where(database.Users.username == kwargs["username"])).scalar()
                    return entry  # returns an object with attributes
            elif "name" in kwargs:
                with self.app.app_context():
                    entry = self.db.session.execute(self.db.select(database.Users).
                                                    where(database.Users.name == kwargs["name"])).scalars().all()
                    return entry  # returns a list of users
            elif "accountType" in kwargs:
                with self.app.app_context():
                    entry = self.db.session.execute(self.db.select(database.Users).
                    where(
                        database.Users.accountType == kwargs["accountType"])).scalars().all()
                    return entry  # returns a list of users

        if db_selection == "logon":
            with self.app.app_context():
                entry = self.db.session.execute(self.db.select(database.SystemLogon).
                                                where(
                    database.SystemLogon.username == kwargs["username"])).scalars().all()
                return entry

    def read_all(self, database_selection):
        """
        :param database: users|logon
        :return: all entries
        """
        if database_selection == "users":
            with self.app.app_context():
                entry = self.db.session.execute(
                    self.db.select(database.Users).order_by(database.Users.username)).scalars().all()
                return entry
        if database_selection == "logon":
            with self.app.app_context():
                entry = self.db.session.execute(self.db.select(database.SystemLogon)).scalars().all()
                return entry

    def update(self, username_, **kwargs):

        """
        :param username_: enter a username to update the user's data
        :param **kwargs name, username, password, accountType
        :return: Update entries in db
        """

        with self.app.app_context():
            entry = self.db.session.execute(self.db.select(database.Users).
                                            where(database.Users.username == username_)).scalar()

            if entry is not None:
                if "name" in kwargs:
                    entry.name = kwargs["name"]
                    self.db.session.commit()
                    return True
                elif "username" in kwargs:
                    entry.username = kwargs["username"]
                    self.db.session.commit()
                    return True
                elif "accountType" in kwargs:
                    entry.accountType = kwargs["accountType"]
                    self.db.session.commit()
                    return True
                elif "password" in kwargs:
                    entry.password = kwargs["password"]
                    self.db.session.commit()
                    return True
            else:
                return False  # if return false, operation denied, user does not exist in database

    def deletion(self, username):

        """
        :param username: enter a username to delete it
        :return: Delete entries in db
        """

        with self.app.app_context():
            entry = self.db.session.execute(self.db.select(database.Users).
                                            where(database.Users.username == username)).scalar()
            if entry is not None:
                self.db.session.delete(entry)
                self.db.session.commit()
            else:
                return {"Error": f"User {username} not found, please enter a valid username"}, 404

    def read_injection(self, **kwargs):

        if "salt" in kwargs:
            with self.app.app_context():
                # injection prompt 'anything' OR '1'='1'
                query = text(f"SELECT * FROM users WHERE salt = {kwargs['salt']}")
                entry = self.db.session.execute(query).fetchall()
                return entry
        elif "username" in kwargs:
            # Username is a unique attribute of every user, so cannot find more than one hence scalar.
            # Server does the handling
            with self.app.app_context():
                # injection prompt 'anything' OR '1'='1'
                query = text(f"SELECT * FROM users WHERE username = '{kwargs['username']}'")
                entry = self.db.session.execute(query).fetchall()
                return entry
        elif "name" in kwargs:
            with self.app.app_context():
                # injection prompt somethign' OR '1=1
                query = text(f"SELECT * FROM users WHERE name = '{kwargs['name']}'")
                entry = self.db.session.execute(query).fetchall()
                return entry
        elif "accountType" in kwargs:
            with self.app.app_context():
                # injection prompt somethign' OR '1=1
                query = text(f"SELECT * FROM users WHERE accountType = '{kwargs['accountType']}'")
                entry = self.db.session.execute(query).fetchall()
                return entry

# -------------OPERATION BLOCK---------------#
