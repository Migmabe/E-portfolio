from cmd import Cmd
import os

class Prompt(Cmd):

    intro = "Welcome! Let's do some operations. Enter 'help' to display the available commands"
    prompt = ">>"

    os.system(f"chmod 740 ")

    def do_LISTS(self, arg):
        """Display current directory content."""
        content = os.listdir()
        for n in content:
            #   Protect my files with the chmod command to avoid tampering
            os.system(f"chmod 740 {n}")
            print(n)

    def do_EXIT(self, arg):
        """Exit the application"""
        print("Bye")
        return True

    def do_ADD(self, args):
        """Adds numbers. Please enter them with a space in between"""
        n = 0
        for _ in args.split():
            n += int(_)
        print(n)

Prompt().cmdloop()
print("Shell exited")

