"""This script is used to run a few tests on the CLI. Since the CLI is fully tested to handle input with booleans,
the only chance for the input not to be valid is when we must choose an option, but we enter a word or string,
this is why the whole script is wrapped with the try except block to raise an exception"""