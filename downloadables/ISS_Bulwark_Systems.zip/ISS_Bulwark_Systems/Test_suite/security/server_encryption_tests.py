"""
This file will check the following for the encrypter:
    1. Assert that the result is a tuple
    2. Assert that the first element is a string
    3. Assert that the second element is an int
    4. Check if the encrypter raises an error when not passed a string

For the decrypter, the following will be checked:
    1. Assert that the decrypter returns a str
    2. Assert that the decrypter returns the original string
"""
# --------------IMPORTS---------------#
import Backend.security.server_encryption as server_encryption
import unittest


# --------------END IMPORTS----------#
class Test_ENCRYPTER(unittest.TestCase):
    client = server_encryption.API_line
    server = server_encryption.SERVER_line

    def test_encrypter(self):
        function = server_encryption.encrypter("thisisastring", self.server, self.client)
        # Assert that the result is a tuple
        print("Checking that encrypter() returns a tuple")
        self.assertIsInstance(function, tuple)
        # Assert that the first element is a string
        print("Checking if the first item is a string")
        self.assertIsInstance(function[0], str)
        # Assert that the second element is an int
        print("Checking if the second item is an int")
        self.assertIsInstance(function[1], float)
        # Check if the encrypter raises an error when not passed a string
        print("Checking if the encrypter handles unwanted input")
        with self.assertRaises(TypeError):
            server_encryption.encrypter(1234, self.server, self.client)

    def test_decrypter(self):
        function = server_encryption.encrypter("thisisastring", self.server, self.client)
        # Assert that the decrypter returns a str
        print("Checking if the decrypter returns a string")
        self.assertIsInstance(server_encryption.decrypter(function[0], function[1], self.client), str)
        # Assert that the decrypter returns the original string
        print("Checking if the original string matches after decryption")
        self.assertEqual(server_encryption.decrypter(function[0], function[1], self.client), "thisisastring")


