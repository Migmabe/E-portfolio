"""This script is used to run a few tests for the GUI.password_checker.py and password_generator_tests.py module. These are
closely related. To check:

    1. Checker function must return a list
    2. Interface_password_checker function returns a list too
    3. Enter a few passwords with several non-compliances to the password rules, see if the checker detects them

I will use the unittest framework -- https://docs.python.org/3/library/unittest.html
"""

import unittest
import GUI.password_checker as password_checker
import GUI.password_generator as password_generator


class Test_PASSWORD_CHECKER(unittest.TestCase):
    faulty_passwords = ["test", "123_", "thisisaveeeerylongpassword", "test space pass 123/"]
    correct_passwords = ["aymimaDre123)", "HolaBuenas12!", "BadBunny:84"]

    def test_checker_and_interface(self):

        self.assertIsInstance(password_checker.checker(self.faulty_passwords[0]), list, "Function checker does not "
                                                                                        "return a list")
        self.assertIsInstance(password_checker.interface_password_checker(password_generator,
                                                                          password=self.correct_passwords[2]), list,
                              "Function interface_password_checker does not return a list")
        for _ in self.faulty_passwords:
            self.assertFalse(password_checker.interface_password_checker(password_generator, password=_)[1])
        for _ in self.correct_passwords:
            self.assertTrue(password_checker.interface_password_checker(password_generator, password=_)[1])


