"""This script is used to run a few tests for the Backend.security.salt_generator.py module. To check:

    1. Salt value is a string between 8 and 16 characters

I will use the unittest framework -- https://docs.python.org/3/library/unittest.html
"""

import unittest
import Backend.security.salt_generator as salt_generator


class Test_SALT(unittest.TestCase):
    result_string = salt_generator.salt

    def test_salt_output(self):
        self.assertIsInstance(self.result_string, str, "Output is not a string")

        # Check if the length of the string is 16 characters
        self.assertEqual(len(self.result_string), 16, "String is not 16 characters")
