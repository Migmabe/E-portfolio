"""This script is used to run a few tests for the Backend.server.db_nav.py module. To check:

    1. Create function writes data on my database, making the database larger
    2. Read function returns an entry that is a list of either len > 0 if it hits an entry and len == 0 if it does not,
    assert if read function returns an empty list when name not found and if returns None when username not found
    3. Read all returns an entry that is not None, and check with the sqlite command
    4. Update returns True if operation is 'name', 'username', 'accountType', 'password' and user exists or False if
    user does not exist
    5. Delete makes the database smaller

I am checking the bare operations are completed accordingly as all the filtering and raising of the errors in handled
at server level. I rebuilt the database, leaving the system logon component out, with a simpler db build than the one
used in the main app.

I will use the unittest framework -- https://docs.python.org/3/library/unittest.html
"""

import unittest
import Backend.server.db_nav as db_nav
import sqlite3
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
import os

base_dir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)


# CREATE DATABASE
class Base(DeclarativeBase):
    pass


database_path = os.path.join(base_dir, "users_test.db")

app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{database_path}"

# Create the extension
db = SQLAlchemy(model_class=Base)
# Initialise the app with the extension
db.init_app(app)


# -----------------CREATE TABLES---------------------------#
class Users(db.Model):
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(nullable=False)
    username: Mapped[str] = mapped_column(unique=True, nullable=False)
    salt: Mapped[str] = mapped_column(nullable=False)
    password: Mapped[str] = mapped_column(nullable=False)
    accountType: Mapped[str] = mapped_column(nullable=False)


with app.app_context():
    db.create_all()


class Interface():
    def __init__(self):
        self.app = app
        self.db = db


class CRUD(Interface):

    def create(self, **kwargs):

        """
        :param kwargs: USER(name, username, password, accountType) || SYSTEMLOGON(username)
        :return: Create entries in db
        """
        if "name" in kwargs:
            with self.app.app_context():
                self.db.session.add(Users(name=kwargs["name"], username=kwargs["username"],
                                          password=kwargs["password"], accountType=kwargs["accountType"],
                                          salt=kwargs["salt"]))
                self.db.session.commit()

    def read(self, **kwargs):

        """
        :param db_selection: either "users" or "logon" to retrieve data from one db or the other
        :param kwargs: USER(name, username, accountType) || SYSTEMLOGON(username)
        :return: Read entries in db
        """
        if "salt" in kwargs:
            with self.app.app_context():
                entry = self.db.session.execute(self.db.select(Users.salt).
                                                where(Users.username == kwargs["username"])).scalar()
                return entry
        elif "username" in kwargs:
            # Username is a unique attribute of every user, so cannot find more than one hence scalar.
            # Server does the handling
            with self.app.app_context():
                entry = self.db.session.execute(self.db.select(Users).
                                                where(Users.username == kwargs["username"])).scalar()
                return entry
        elif "name" in kwargs:
            with self.app.app_context():
                entry = self.db.session.execute(self.db.select(Users).
                                                where(Users.name == kwargs["name"])).scalars().all()
                return entry
        elif "accountType" in kwargs:
            with self.app.app_context():
                entry = self.db.session.execute(self.db.select(Users).
                where(
                    Users.accountType == kwargs["accountType"])).scalars().all()
                return entry

    def read_all(self):
        """
        :param database: users|logon
        :return: all entries
        """
        with self.app.app_context():
            entry = self.db.session.execute(
                self.db.select(Users).order_by(Users.username)).scalars().all()
            return entry

    def update(self, username_, **kwargs):

        """
        :param username_: enter a username to update the user's data
        :param **kwargs name, username, password, accountType
        :return: Update entries in db
        """

        with self.app.app_context():
            entry = self.db.session.execute(self.db.select(Users).
                                            where(Users.username == username_)).scalar()

            if entry is not None:
                if "name" in kwargs:
                    entry.name = kwargs["name"]
                    self.db.session.commit()
                    return True
                elif "username" in kwargs:
                    entry.username = kwargs["username"]
                    self.db.session.commit()
                    return True
                elif "accountType" in kwargs:
                    entry.accountType = kwargs["accountType"]
                    self.db.session.commit()
                    return True
                elif "password" in kwargs:
                    entry.password = kwargs["password"]
                    self.db.session.commit()
                    return True
            else:
                return False  # if return false, operation denied, user does not exist in database

    def deletion(self, username):

        """
        :param username: enter a username to delete it
        :return: Delete entries in db
        """

        with self.app.app_context():
            entry = self.db.session.execute(self.db.select(Users).
                                            where(Users.username == username)).scalar()
            if entry is not None:
                self.db.session.delete(entry)
                self.db.session.commit()
            else:
                return {"Error": f"User {username} not found, please enter a valid username"}, 404


# -------------OPERATION BLOCK---------------#

class Test_DB_NAV(unittest.TestCase):

    def test_create(self):
        self.crud = CRUD()
        connection = sqlite3.connect(f'{database_path}')
        cursor = connection.cursor()
        count1 = cursor.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        self.crud.create(name="Pedrito", username="usernametest", accountType="admin", password="testpass12433A",
                         salt="adwre34f33N")
        count2 = cursor.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        self.assertGreater(count2, count1, "No data was written to the database")
        self.crud.deletion("usernametest")
        cursor.close()
        connection.close()

    def test_read(self):
        self.crud = CRUD()
        self.crud.create(name="Pedrito", username="usernametest", accountType="admin", password="testpass12433A",
                         salt="adwre34f33N")
        self.assertIsInstance(self.crud.read(name="Pedrito"), list, "Read function must return a list")
        # Assert if read function returns an empty list when name not found
        self.assertTrue(len(self.crud.read(name="Sebastian")) == 0, "Read function of something ")
        self.assertIsInstance(self.crud.read(username="usernametest"), object, "Read function for username must return an object")
        # Assert if read function returns None when username not found
        self.assertTrue(self.crud.read(username="usernametest2") is None, "Read function is not None when username is not found")
        self.assertTrue(len(self.crud.read(name="Pedrito")) > 0, "Error in read function, it didn't find the created user")
        self.assertTrue(len(self.crud.read(name="Bryan")) == 0, "Error in read function return, should be none if user not in database")
        self.crud.deletion("usernametest")

    def test_read_all(self):
        self.crud = CRUD()
        self.crud.create(name="Pedrito", username="usernametest", accountType="admin", password="testpass12433A",
                         salt="adwre34f33N")
        connection = sqlite3.connect(f'{database_path}')
        cursor = connection.cursor()
        count = cursor.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        self.assertEqual(count, len(self.crud.read_all()), "Read_all function did not return all the data")
        self.crud.deletion("usernametest")
        cursor.close()
        connection.close()

    def test_update(self):
        self.crud = CRUD()
        self.crud.create(name="Pedrito", username="usernametest", accountType="admin", password="testpass12433A",
                         salt="adwre34f33N")
        self.assertTrue(self.crud.update("usernametest", name="Pedro"), "Update function could not change user's name")
        self.assertTrue(self.crud.update("usernametest", username="thisisanewusernameyeah"),
                        "Update function could not change username")
        self.assertTrue(self.crud.update("thisisanewusernameyeah", accountType="user"), "Update function could not change user's account type")
        self.assertTrue(self.crud.update("thisisanewusernameyeah", password="newpassword243QAawe"), "Update function could not change user's password")
        self.assertFalse(self.crud.update("differentusername", name="Julian"), "Update function updated a user's attribute for a non-registered user")
        self.crud.deletion("thisisanewusernameyeah")

    def test_deletion(self):
        self.crud = CRUD()
        self.crud.create(name="Pedrito", username="usernametest", accountType="admin", password="testpass12433A",
                         salt="adwre34f33N")
        # Perform the delete operation here
        self.crud.deletion("usernametest")
        self.assertTrue(len(self.crud.read_all()) == 0, "There are still users in the database, user not deleted")


