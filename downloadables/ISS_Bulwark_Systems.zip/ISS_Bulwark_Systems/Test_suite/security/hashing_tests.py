"""This script is used to run a few tests for the Backend.security.hashing.py module. To check:

    1. gen_hashing function properly handles input in non-desired format
    2. check_hash function matches hashes correctly, and incorrectly if given a wrong salt key

I will use the unittest framework -- https://docs.python.org/3/library/unittest.html
"""

# --------------IMPORTS---------------#

import unittest
import Backend.security.hashing as hashing

# --------------END IMPORTS----------#

class Test_GEN_HASHING(unittest.TestCase):

    def test_gen_hashing(self):
        self.assertIsNotNone(hashing.gen_hashing("MyPass123"))
        # Match raised error case using this line if error in this case then OK
        with self.assertRaises(ValueError):
            hashing.gen_hashing(123)


class Test_CHECK_HASH(unittest.TestCase):
    test_pass = "ThisIsATestPass4)"
    hashed_pass_test = hashing.gen_hashing(test_pass)
    def test_check_hash(self):
        self.assertTrue(hashing.check_hash(self.hashed_pass_test[0], self.test_pass, self.hashed_pass_test[1]))


