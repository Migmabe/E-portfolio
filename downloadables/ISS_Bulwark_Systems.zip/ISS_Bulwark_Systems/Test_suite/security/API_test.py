"""
This script will test the Backend.API.API_test.py module, and check the following:

    1. Check the json_handler returns a normal dictionary when decrypting and a dictionary with tuples for values on each
    key for the encrypted one, and raise a TypeError if operation not 'encrypt' or 'decrypt'. Decryption must match server encryption
    2. Jsonify_adapter function and jsonify_adapter_admin function return a list of dictionaries
    3. Post reaches the endpoint and sends the received data back and 200 server code and fails when key not provided (error code FORBIDDEN 403)
    4. Get reaches the endpoint in encrypted and decrypted format and returns a dictionary and fails when key not provided (error code FORBIDDEN 403)
    5. Patch reaches the endpoint and sends the received data back and 200 server code and fails when key not provided (error code FORBIDDEN 403)
    6. Delete reaches the endpoint and sends the received data back and 200 server code and fails when key not provided (error code FORBIDDEN 403)
"""

import unittest
import Backend.server.server as server_functions
import Backend.API.API as API
from flask import Flask, jsonify, request
import Backend.security.server_encryption as server_encryption
import threading

request_filtered = None


class Dummy_Object:

    def __init__(self):
        self.name = "Nicole"
        self.username = "nicoleta"
        self.salt = "vWLhXctuETehiG2H"
        self.password = "y2c:x7y409T"
        self.accountType = "admin"


class DummySecurityFileOFF:
    def __init__(self, security=True, accountType="admin", username="nicoliflow"):
        """
        :param timeout in SECS
        """
        self.security = security
        self.accountType = accountType
        self.username = username


class DummySecurityFileON:
    def __init__(self, security=False, accountType="admin", username="nicoliflow"):
        """
        :param timeout in SECS
        """
        self.security = security
        self.accountType = accountType
        self.username = username


class DummyServer:
    def __init__(self, security):
        self.app = Flask(__name__)
        self.security = security
        self.data = {"name": "Nicole",
                     "username": "nicoleta",
                     "salt": "vWLhXctuETehiG2H",
                     "password": "y2c:x7y409T",
                     "accountType": "admin"}
        self.initialize_routes()

    def initialize_routes(self):

        @self.app.before_request
        # Check the API key, contained in the header
        def filter_request():
            if self.security:
                pass
            else:
                cipher, key = request.headers.get("Authorization").split(",")
                original_value = server_encryption.decrypter(cipher, float(key),
                                                             server_encryption.SERVER_line)
                if original_value == "myAPIkey8)":
                    global request_filtered
                    request_filtered = True
                    pass
                else:
                    return 403

        @self.app.route('/users/<string:attribute>',
                        methods=["GET"])  # http://127.0.0.1:5001/users/username?value=nicoleta
        def get(attribute):
            if request.method == "GET":
                value = request.args.get("value")
                if self.security:
                    return jsonify([self.data]), 200
                elif not self.security:
                    cipher, key = value.split(",")
                    a = attribute
                    original_value = server_encryption.decrypter(cipher, float(key),
                                                                 server_encryption.SERVER_line)
                    # Return the retrieved data in encrypted format, then API decrypts it and checks if it is the same as the test data dict
                    return server_functions.jsonify_adapter_admin([Dummy_Object()], "encrypt"), 200
                else:
                    return 400
            else:
                return 404

        @self.app.route("/add/user", methods=["POST"])
        def post():
            if self.security:
                return jsonify(request.json), 200
            else:
                # Return the decrypted version of the sent data, API then checks if it's the same when decrypting as the test data dict
                return server_functions.json_handler("decrypt", request.json), 200

        @self.app.route("/modify/<string:username>", methods=["PATCH"])
        def patch(username):
            if request.method == "PATCH":
                if self.security:
                    a = username
                    return jsonify(request.json), 200
                else:
                    return jsonify(server_functions.json_handler("decrypt", request.json)), 200
            else:
                return 500

        @self.app.route("/delete/<string:username>", methods=["DELETE"])
        def delete(username):
            if self.security:
                a = username
                return jsonify({"username": "nicoleta"}), 200
            else:
                cipher, key = username.split(",")
                original_message = server_encryption.decrypter(cipher, float(key), server_encryption.SERVER_line)
                return jsonify([original_message]), 200

    def run(self):
        self.app.run(port=5001, debug=True, use_reloader=False)


class Test_FUNCTIONS(unittest.TestCase):
    user = Dummy_Object()
    dictionary = {"name": "Nicole",
                  "username": "nicoleta",
                  "salt": "vWLhXctuETehiG2H",
                  "password": "y2c:x7y409T",
                  "accountType": "admin"}
    # Encrypted by server
    encrypted_dict = server_functions.json_handler("encrypt", dictionary)

    def test_json_handler(self):
        self.assertIsInstance(API.json_handler("decrypt", self.encrypted_dict), dict,
                              "json_handler does not return a dictionary")
        # Encrypted and decrypted data must be the same
        self.assertEqual(API.json_handler("decrypt", self.encrypted_dict), self.dictionary,
                         "Encryption and decryption do not match")
        # The encryption should return a dictionary with tuples as values
        self.assertIsInstance(API.json_handler("encrypt", self.dictionary)["name"], tuple,
                              "json_handler must have tuples for values")

    def test_jsonify_adapter(self):
        self.assertIsInstance(API.jsonify_adapter([self.user]), list, "jsonify_adapter does not return a list")
        self.assertIsInstance(API.jsonify_adapter_admin([self.user]), list,
                              "jsonify_adapter_admin does not return a list")
        # Admin must return every attribute so its dictionary must be bigger
        self.assertTrue(
            len(API.jsonify_adapter([self.user])[0].items()) < len(API.jsonify_adapter_admin([self.user])[0].items()),
            "jsonify_adapter_main does not return all attributes")


class Test_API_security_OFF(unittest.TestCase):
    api = API.API_OBJECT(DummySecurityFileOFF())
    #thread = threading.Thread(target=DummyServer(True).run)
    #thread.daemon = True
    #thread.start()
    dictionary = {"name": "Nicole",
                  "username": "nicoleta",
                  "salt": "vWLhXctuETehiG2H",
                  "password": "y2c:x7y409T",
                  "accountType": "admin"}

    def tests_requests(self):
        # Post
        response = self.api.post(data=self.dictionary)
        self.assertTrue(response[0] == self.dictionary, "Server did not return the posted data")
        self.assertTrue(response[1] == 200, "Server did not receive post request")
        # Get
        response2 = self.api.get("username", "nicoleta")
        self.assertTrue(response2[0][0] == self.dictionary, "Server did not return the get data")
        self.assertTrue(response2[1] == 200, "Server did not receive get request")
        # Patch
        response3 = self.api.patch("nicoleta", {"name": "Nicole"})
        self.assertTrue(response3[0] == {"name": "Nicole"}, "Server did not return the patched data")
        self.assertTrue(response3[1] == 200, "Server did not receive patch request")
        # Delete
        response4 = self.api.delete("nicoleta")
        self.assertTrue(response4[0] == {"username": "nicoleta"}, "Server did not return the deleted data")
        self.assertTrue(response3[1] == 200, "Server did not receive delete request")


class Test_API_security_ON(unittest.TestCase):
    api = API.API_OBJECT(DummySecurityFileON())
    thread = threading.Thread(target=DummyServer(False).run)
    thread.daemon = True
    thread.start()
    dictionary = {"name": "Nicole",
                  "username": "nicoleta",
                  "salt": "vWLhXctuETehiG2H",
                  "password": "y2c:x7y409T",
                  "accountType": "admin"}

    def tests_requests(self):
        global request_filtered
        # Post
        request_filtered = False
        request = self.api.post(data=self.dictionary)
        self.assertTrue(request_filtered, "Request was not filtered on post")
        self.assertTrue(self.dictionary == request[0], "API encrypts but server could not properly decrypt")
        # Get
        request_filtered = False
        request2 = self.api.get("username", "nicoleta")
        self.assertTrue(request_filtered, "Request was not filtered on get")
        self.assertTrue(request2[0][0] == self.dictionary, "Server encrypts but API could not properly decrypt")
        # Patch
        request_filtered = False
        response3 = self.api.patch("nicoleta", {"name": "Nicole"})
        self.assertTrue(request_filtered, "Request was not filtered on patch")
        self.assertTrue({"name": "Nicole"} == response3[0], "API encrypts but server could not properly decrypt")
        # Delete
        request_filtered = False
        response4 = self.api.delete("nicoleta")
        self.assertTrue(request_filtered, "Request was not filtered on delete")
        self.assertTrue(response4[0][0] == "nicoleta", "Server properly decrypts")

