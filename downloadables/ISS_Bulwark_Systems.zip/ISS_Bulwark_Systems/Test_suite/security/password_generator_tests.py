"""This script is used to run a few tests for the GUI.password_generator_tests.py module. To check:

    1. Generator function returns a string between 8 and 16 characters
    2. Word slicer function returns a string that is longer than the faulty string
    3. Filter function returns a string that when checked with the password checker will not return False

I will use the unittest framework -- https://docs.python.org/3/library/unittest.html
"""

# ------------VARIABLES-------------#

variable_dictionary = {

    "capital_letters": ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
                        "T", "U", "V", "W", "X", "Y", "Z"],

    "lowercase_letters": ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
                          "t", "u", "v", "w", "x", "y", "z"],

    "numbers": ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],

    "special_characters": [")", "(", "^", "!", ";", ":", "]", "[", "–", "~", "$", "@", "_"],

}

# -----------END------------#


import unittest
import GUI.password_generator as password_generator
import GUI.password_checker as password_checker


class Test_PASSWORD_GENERATOR(unittest.TestCase):
    generation = password_generator.generator()

    def test_generator(self):
        self.assertTrue(8 <= len(self.generation) <= 16, "Password generator length must be "
                                                                                  "between 8 and 16 characters")

    def test_slicer(self):
        self.assertIsInstance(password_generator.word_slicer("hello", "3"), str, "Word slicer function must return a "
                                                                                 "string")
        self.assertGreater(len(password_generator.word_slicer("hellotest", "A")), len("hellotest"), "Word slicer must return "
                                                                                             "a longer string than "
                                                                                             "what was fed")

    def test_filter(self):
        self.assertIsInstance(password_generator.filter(), str, "Filter function is not returning a string")
        self.assertTrue(password_checker.checker(password_generator.filter()), "Generated function does not comply "
                                                                               "with the password rules")

