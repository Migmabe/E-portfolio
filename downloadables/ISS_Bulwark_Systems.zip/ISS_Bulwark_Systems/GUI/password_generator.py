#   This file will generate a random password with the following requirements
"""
-	8 digits long
-	At  least 1 lower and 1 uppercase letter and 1 number
-	Valid especial characters: )(^!;:][–~$@_
-	No spaces allowed (mitigating injection)
-	When clicking generate, a random password with these requirements will be created

"""

#---------IMPORTS----------

import random

import re

#---------VALID CHARACTERS------

variable_dictionary = {

    "capital_letters": ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
                        "T", "U", "V", "W", "X", "Y", "Z"],

    "lowercase_letters": ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
                          "t", "u", "v", "w", "x", "y", "z"],

    "numbers": ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],

    "special_characters": [")", "(", "^", "!", ";", ":", "]", "[", "–", "~", "$", "@", "_"],

}


#---------FUNCTIONS--------

def generator():
    """Generates password"""

    password = ""

    #   Length of generated password random number

    length = random.randint(8, 16)

    for _ in range(0, length):
        #   Create a list from the dictionary keys and randomly select 1
        dict_pick = random.choice(list(variable_dictionary.keys()))
        password += variable_dictionary[dict_pick][random.randint(0, len(variable_dictionary[dict_pick]) - 1)]

    return password


def word_slicer(word, character):
    """This function returns a word with an inserted character at a random position"""
    #   Define a random position, within the limits of the passed word's length
    random_position = random.randint(0, len(word) - 1)
    new_word = word[:random_position] + f"{character}" + word[random_position:]
    return new_word


def filter():
    """This function will determine if the password is valid and returned a filtered version
    so it complies with the specified rule. Regex is used to check and filter."""

    password = generator()

    #   Regex pattern compiled only once

    capitals = re.compile(r"[A-Z]{1,}")
    lowercase = re.compile(r"[a-z]{1,}")
    numerals = re.compile(r"[0-9]{1,}")

    if capitals.search(password) is None:
        #   Insert random character within the specified category
        password = word_slicer(password, variable_dictionary["capital_letters"]
        [random.randint(0, len(variable_dictionary["capital_letters"])-1)])

    if lowercase.search(password) is None:
        #   Insert random character within the specified category
        password = word_slicer(password, variable_dictionary["lowercase_letters"]
        [random.randint(0, len(variable_dictionary["lowercase_letters"])-1)])

    if numerals.search(password) is None:
        #   Insert random character within the specified category
        password = word_slicer(password, variable_dictionary["numbers"]
        [random.randint(0, len(variable_dictionary["numbers"])-1)])

    #   Return modified and filtered password and True, used to log in
    return password
