#---------IMPORTS---------

from tkinter import *

#Import the password generator and link it to the generate button

import GUI.password_generator as password_generator
import GUI.password_checker as password_checker
import settings
import sqlite3
import Backend.security.hashing as hashing

#----------WINDOW-----------

window = Tk()
window.title("Password Manager")
window.config(padx=25, pady=25)
window.resizable(False, False)

#---------GLOBAL CONSTANTS------------


TITLE_FONT = ("arial", 40, "bold")
LOGIN_FONT = ("arial", 24, "underline", "italic")
REGULAR_FONT = ("arial", 14)
dropdown_options = ["ADMIN", "USER"]
#The login function will call the password_checker module if value is 1. If not, checker will assume password is
# correct as it was generated
password_check_selector: int = 2
#To destroy dummies when clicking login button
dummy_labels = list()
login_tries = 0
settings_file = None


#---------FUNCTIONS--------------

def password_generator_action():
    """This function places my generated password """
    global password_check_selector
    password_entry.entry.delete(0, END)
    password_check_selector = 0
    generated_password = password_generator.filter()
    password_entry.entry.insert(0, generated_password)


def user_register():
    """Will be launched when the register button is clicked"""
    global dummy_labels
    password_ = password_entry.entry.get()
    if len(dummy_labels) != 0:
        for _ in dummy_labels:
            _.destroy()
    if password_checker.interface_password_checker(password_generator, password=password_)[1] or password_check_selector == 0:
        username_ = username_entry.entry.get()
        connection = sqlite3.connect("Backend/server/users.db")
        cursor = connection.cursor()
        cursor.execute("SELECT salt FROM users WHERE username = ?", (username_,))
        salt = cursor.fetchone()[0]
        password_hash = hashing.gen_hashing(password_, salt)
        cursor.execute("UPDATE users SET password = ? WHERE username = ?", (password_hash, username_))
        connection.commit()
        cursor.close()
        connection.close()
    # Regardless of writing the new data in or not, we run login to check for the input
    login_action()


# Here the function that will generate the settings list, to initialize the settings class
def settings_gen(password):
    global login_tries
    global dummy_labels
    if len(dummy_labels) != 0:
        for _ in dummy_labels:
            _.destroy()
    settings = []  # must be of length 3 with the ordered entries [security, accountType, username]
    if login_tries < 4 or checked_state.get() == 0: # If 0, security is OFF so security == True
        # First, get hold of the security setting
        if checked_state.get() == 1:
            security = False
            settings.append(security)
        else:
            security = True
            settings.append(security)
        # Then, get hold of the accountType
        if option_var.get() != "ADMIN" and option_var.get() != "USER":
            dormant_login_label1 = Label(text="Please select user credentials", fg="red")
            dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
            dummy_labels = [dormant_login_label1]
        else:
            settings.append(option_var.get().lower())
        # Finally, get hold of the username with the condition that it exists in the database
            username_ = username_entry.entry.get()
            # Read the database
            connection = sqlite3.connect("Backend/server/users.db")
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM users WHERE username = ? AND accountType = ?",
                           (username_, option_var.get().lower()))
            hit_username = cursor.fetchone()
            cursor.close()
            connection.close()
            if hit_username:
                if password == "Azerty00":
                    if hashing.check_hash(hit_username[3], password, hit_username[4]):
                        dormant_login_label1 = Label(text="To complete user registration, please either generate or create password",
                                                     fg="blue")
                        dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                        dummy_labels = [dormant_login_label1]
                        return []
                    else:
                        dormant_login_label1 = Label(
                            text="Password is not correct. Please review your login details",
                            fg="red")
                        dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                        dummy_labels = [dormant_login_label1]
                elif hashing.check_hash(hit_username[3], password, hit_username[4]):
                    settings.append(username_)
                    print("Login successful")
                else:
                    dormant_login_label1 = Label(
                        text="Password is not correct. Please review your login details",
                        fg="red")
                    dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                    dummy_labels = [dormant_login_label1]
            else:
                dormant_login_label1 = Label(text="User not found in database. Please review your login details",
                                             fg="red")
                dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                dummy_labels = [dormant_login_label1]
    else:
        dormant_login_label1 = Label(text="Login attempts exceeded", fg="red")
        dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
        dummy_labels = [dormant_login_label1]

    return settings


#   Here the login function, very important
def login_action():
    global dummy_labels
    global login_tries
    global settings_file
    login_tries += 1
    #Everytime the login button is pressed, the dummy labels are deleted and
    if len(dummy_labels) != 0:
        for _ in dummy_labels:
            _.destroy()

    if password_check_selector == 0 and username_entry.entry.get() is not None:
        #enter application and get() whatever is on the entry to save it to the user pool
        check_settings = settings_gen(password_entry.entry.get())
        if len(check_settings) == 3:
            settings_file = settings.Main(check_settings[0], check_settings[1], check_settings[2])
            # Close program and return settings file
            window.destroy()
            return settings_file
        elif len(check_settings) == 0:
            register_button = Button(text="Register", width=7, command=user_register)
            register_button.grid(column=2, row=7, sticky="ew")

    elif password_check_selector == 1 and username_entry.entry.get() is not None:
        #Save the manual checked password after checking the returned output, if True.
        manual_password = password_checker.interface_password_checker(password_generator,
                                                                      password=password_entry.entry.get())
        if manual_password[1]:
            #Enter application and get() password to save it in our user pool
            check_settings = settings_gen(password_entry.entry.get())
            if len(check_settings) == 3:
                settings_file = settings.Main(check_settings[0], check_settings[1], check_settings[2])
                # Close program and return settings file
                window.destroy()
                return settings_file
            elif len(check_settings) == 0:
                register_button = Button(text="Register", width=7, command=user_register)
                register_button.grid(column=2, row=7, sticky="ew")
        else:
            if len(manual_password[0]) == 1:
                dormant_login_label1 = Label(text=f"{manual_password[0][0]}", fg="red")
                dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                dummy_labels = [dormant_login_label1]
            elif len(manual_password[0]) == 2:
                dormant_login_label1 = Label(text=f"{manual_password[0][0]}", fg="red")
                dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                dormant_login_label2 = Label(text=f"{manual_password[0][1]}", fg="red")
                dormant_login_label2.grid(column=0, row=9, columnspan=3, sticky="w")
                dummy_labels = [dormant_login_label1, dormant_login_label2]
            elif len(manual_password[0]) == 3:
                dormant_login_label1 = Label(text=f"{manual_password[0][0]}", fg="red")
                dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                dormant_login_label2 = Label(text=f"{manual_password[0][1]}", fg="red")
                dormant_login_label2.grid(column=0, row=9, columnspan=3, sticky="w")
                dormant_login_label3 = Label(text=f"{manual_password[0][2]}", fg="red")
                dormant_login_label3.grid(column=0, row=10, columnspan=3, sticky="w")
                dummy_labels = [dormant_login_label1, dormant_login_label2, dormant_login_label3]
            elif len(manual_password[0]) == 4:
                dormant_login_label1 = Label(text=f"{manual_password[0][0]}", fg="red")
                dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                dormant_login_label2 = Label(text=f"{manual_password[0][1]}", fg="red")
                dormant_login_label2.grid(column=0, row=9, columnspan=3, sticky="w")
                dormant_login_label3 = Label(text=f"{manual_password[0][2]}", fg="red")
                dormant_login_label3.grid(column=0, row=10, columnspan=3, sticky="w")
                dormant_login_label4 = Label(text=f"{manual_password[0][3]}", fg="red")
                dormant_login_label4.grid(column=0, row=11, columnspan=3, sticky="w")
                dummy_labels = [dormant_login_label1, dormant_login_label2, dormant_login_label3, dormant_login_label4]
            elif len(manual_password[0]) == 5:
                dormant_login_label1 = Label(text=f"{manual_password[0][0]}", fg="red")
                dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
                dormant_login_label2 = Label(text=f"{manual_password[0][1]}", fg="red")
                dormant_login_label2.grid(column=0, row=9, columnspan=3, sticky="w")
                dormant_login_label3 = Label(text=f"{manual_password[0][2]}", fg="red")
                dormant_login_label3.grid(column=0, row=10, columnspan=3, sticky="w")
                dormant_login_label4 = Label(text=f"{manual_password[0][3]}", fg="red")
                dormant_login_label4.grid(column=0, row=11, columnspan=3, sticky="w")
                dormant_login_label5 = Label(text=f"{manual_password[0][4]}", fg="red")
                dormant_login_label5.grid(column=0, row=12, columnspan=3, sticky="w")
                dummy_labels = [dormant_login_label1, dormant_login_label2, dormant_login_label3, dormant_login_label4,
                                dormant_login_label5]
    elif password_check_selector == 2 and (username_entry.entry.get() is None or username_entry.entry.get() == "..."):
        dormant_login_label1 = Label(text="Please enter a username", fg="red")
        dormant_login_label1.grid(column=0, row=8, columnspan=3, sticky="w")
        dormant_login_label2 = Label(text="Please enter a password", fg="red")
        dormant_login_label2.grid(column=0, row=9, columnspan=3, sticky="w")
        dummy_labels = [dormant_login_label1, dormant_login_label2]
    else:
        raise ValueError("password_check_selector variable neither 0 or 1")


#---------CANVAS----------

canvas = Canvas(width=189, height=200)
lock_img = PhotoImage(file="GUI/Resources/logo.png")
canvas.create_image(100, 100, image=lock_img)

#-------WIDGETS----------

#LABELS

login = Label(text="LOGIN", font=LOGIN_FONT)
title = Label(text="ISS Bulwark Systems", font=TITLE_FONT)
account = Label(text="Account Type", font=REGULAR_FONT)
username = Label(text="Username:", font=REGULAR_FONT)
password = Label(text="Password:", font=REGULAR_FONT)

#DUMMY LABELS

dummy1 = Label(text="")

#BUTTON


generate_password = Button(text="GENERATE", anchor="center", width=7, command=password_generator_action)
login_button = Button(text="Login", width=7, command=login_action)

#CHECKBUTTON

checked_state = IntVar()
security_checkbutton = Checkbutton(text="Security ON?", variable=checked_state)


#ENTRY

class Entries:

    def __init__(self):
        self.entry = Entry(textvariable=StringVar(value="..."))

    def entry_blanker(self, dummy):
        """Removes initial text when entry clicked and sets the selector to 1"""
        global password_check_selector
        if self.entry.get() == "...":
            password_check_selector = 1
            self.entry.delete(0, END)
        elif self.entry.get() is None:
            password_check_selector = 2



username_entry = Entries()
#   when focusin (handler), the entry blanker function is called
username_entry.entry.bind("<FocusIn>", username_entry.entry_blanker)

password_entry = Entries()
password_entry.entry.bind("<FocusIn>", password_entry.entry_blanker)

#DROPDOWN/OPTION MENU

option_var = StringVar(window)
option_var.set("Select your credentials")
dropdown = OptionMenu(window, option_var, *dropdown_options)

#---------GRID SYSTEM-----------

#   Will do 3 columns and 7 rows

canvas.grid(column=1, row=1)
login.grid(column=0, row=2, sticky="w")
title.grid(column=1, row=0)
account.grid(column=0, row=4, sticky="w")
username.grid(column=0, row=5, sticky="w")
password.grid(column=0, row=6, sticky="w")
generate_password.grid(column=2, row=6, ipady=0.5, sticky="ew")
username_entry.entry.grid(column=1, row=5, columnspan=2, sticky="ew", padx=(4, 0))
password_entry.entry.grid(column=1, row=6, sticky="ew", padx=(4, 0))
dropdown.grid(column=1, row=4, columnspan=2, sticky="ew", padx=(4, 0))
login_button.grid(column=1, row=7)
dummy1.grid(column=0, row=3, pady=1)
security_checkbutton.grid(column=1, row=2)

#---------LOOP---------

window.mainloop()
