import signal
import sys
import Backend.security.hashing as hashing
import random


class CLI:
    def __init__(self, settings_file, api_object):
        self.security = settings_file.security
        self.timeout = settings_file.timeout
        self.api = api_object
        self.alarm = signal.signal(signal.SIGALRM, self.timeout_handler)

    def timeout_handler(self, signum, frame):
        print(f"\nNo interaction detected for {self.timeout} seconds. Exiting the application.")
        sys.exit(0)

    def reset_alarm(self):
        signal.alarm(self.timeout)

    def main(self):
        print("Hi, welcome to the ISS Bulwark Systems APP\n")
        while True:
            print("\nMAIN MENU\n"
                  "Please select one of the following options:\n\n\t1. User operations\n\t2. Check deck vitals\n\t3. "
                  "Check system logons (ADMINS ONLY)\n\t4. Exit application\n")
            try:
                selection1 = int(input("Your selection: "))
                self.reset_alarm()
                if selection1 == 1:
                    while True:
                        print(
                            "\nUser operations:\n\n\t1. Retrieve user\n\t2. Create user\n\t3. Modify user\n\t4. Delete "
                            "user\n\t5. Return to main menu\n")
                        selection2 = int(input("Your selection: "))
                        self.reset_alarm()
                        if selection2 == 1:
                            return_to_main = False
                            while True:
                                print(
                                    "\nHow would you like to retrieve the user's data?\n\n\t1. By username, enter 'username'\n\t2. By name, enter 'name'\n\t3. By account type, enter 'accountType'\n\t4. Go back one level\n\t5. Return to main menu")
                                attribute = input("\nYour selection: ")
                                self.reset_alarm()
                                if attribute == "username":
                                    value = input("\nWhat's the user's username?: ")
                                    print("\n")
                                    self.reset_alarm()
                                    self.api.get(attribute, value)
                                elif attribute == "name":
                                    value = input("\nWhat's the user's name?: ")
                                    print("\n")
                                    self.reset_alarm()
                                    self.api.get(attribute, value)
                                elif attribute == "accountType":
                                    value = input("\nWhat's the user's account type? Please enter 'user' or 'admin': ")
                                    print("\n")
                                    self.reset_alarm()
                                    if value != "user" and value != "admin":
                                        print("Invalid entry, please enter 'user' or 'admin'\n")
                                    else:
                                        self.api.get(attribute, value)
                                elif attribute == "4":
                                    print("\nGoing back one level...")
                                    break
                                elif attribute == "5":
                                    print("\nReturning to main menu...\n")
                                    return_to_main = True
                                    break
                                else:
                                    print(f"\nYou selected {attribute}. What value would you like to search for?\n")
                                    value = input("Your selection: ")
                                    print("\n")
                                    self.reset_alarm()
                                    self.api.get(attribute, value)
                            if return_to_main:
                                break
                        elif selection2 == 2:
                            return_to_main = False
                            while True:
                                name = input("\nPlease, enter the name of the user you want to create: ")
                                self.reset_alarm()
                                username = input("\nPlease, enter the username of the user you want to create: ")
                                self.reset_alarm()
                                accountType = input("\nPlease, enter the account type of the user you want to create 'admin' or 'user': ")
                                self.reset_alarm()
                                if accountType != "user" and accountType != "admin":
                                    print("Invalid entry, going back one level, you must repeat the operation")
                                    break
                                password = hashing.gen_hashing(input(
                                    "\nPlease, enter the password. If new user, please enter the default password 'Azerty00': "))
                                self.reset_alarm()
                                data = {"name": name, "username": username, "accountType": accountType,
                                        "password": password[1], "salt": password[0]}
                                self.api.post(data)
                                choice = input("\nDo you want to create another user? Yes or No: ")
                                self.reset_alarm()
                                if choice.lower() == "yes":
                                    pass
                                elif choice.lower() == "no":
                                    choice2 = input("\nBack one level enter 'back' or return to main menu enter 'main': ")
                                    self.reset_alarm()
                                    if choice2 == "back":
                                        print("\nInvalid choice. Going back one level...")
                                        break
                                    elif choice2 == "main":
                                        print("\nReturning to main menu...\n")
                                        return_to_main = True
                                        break
                                    else:
                                        print("\nInvalid choice. Going back one level...")
                                        break
                                else:
                                    print("\nInvalid choice. Going back one level...")
                                    break
                            if return_to_main:
                                break
                        elif selection2 == 3:
                            return_to_main = False
                            while True:
                                username = input("\nWhat user would you like to modify? Please enter its username: ")
                                self.reset_alarm()
                                parameter = input(
                                    "\nPlease enter the parameter you would like to change ('name', 'username', "
                                    "'password', 'accountType' for ADMINS ONLY): ")
                                self.reset_alarm()
                                value = input("\nWhat do you want to change the parameter to?: ")
                                self.reset_alarm()
                                self.api.patch(username, {f"{parameter}": f"{value}"})
                                choice = input("\nDo you want to modify another user? Yes or No: ")
                                self.reset_alarm()
                                if choice.lower() == "yes":
                                    pass
                                elif choice.lower() == "no":
                                    choice2 = input("\nBack one level enter 'back' or return to main menu enter 'main': ")
                                    self.reset_alarm()
                                    if choice2 == "back":
                                        print("\nInvalid choice. Going back one level...")
                                        break
                                    elif choice2 == "main":
                                        print("\nReturning to main menu...\n")
                                        return_to_main = True
                                        break
                                    else:
                                        print("\nInvalid choice. Going back one level...")
                                        break
                                else:
                                    print("\nInvalid choice. Going back one level...")
                                    break
                            if return_to_main:
                                break
                        elif selection2 == 4:
                            return_to_main = False
                            while True:
                                username = input("\nWhat user would you like to delete? Please enter its username: ")
                                self.reset_alarm()
                                self.api.delete(username)
                                choice = input("\nDo you want to delete another user? Yes or No: ")
                                self.reset_alarm()
                                if choice.lower() == "yes":
                                    pass
                                elif choice.lower() == "no":
                                    choice2 = input("\nBack one level enter 'back' or return to main menu enter 'main': ")
                                    self.reset_alarm()
                                    if choice2 == "back":
                                        print("\nInvalid choice. Going back one level...")
                                        break
                                    elif choice2 == "main":
                                        print("\nReturning to main menu...\n")
                                        return_to_main = True
                                        break
                                    else:
                                        print("\nInvalid choice. Going back one level...")
                                        break
                                else:
                                    print("\nInvalid choice. Going back one level...")
                                    break
                            if return_to_main:
                                break
                        elif selection2 == 5:
                            print("\nReturning to main menu...\n")
                            break
                        else:
                            print("Your selection was out of range.")
                elif selection1 == 2:
                    while True:
                        # Randomly generate oxygen, cabin temperature and cabin pressure levels
                        values = [8 + (30-8) * random.random(), 40 * random.random(), 30 * random.random()]
                        print(
                            "\nDeck vitals:\n\n\t1. Check oxygen levels\n\t2. Check cabin temperature\n\t3. Check cabin "
                            "pressure\n\t4. Go to main menu\n")
                        selection2 = int(input("Your selection: "))
                        self.reset_alarm()
                        if selection2 == 1:
                            while True:
                                if 19.5 <= values[0] <= 23.5:
                                    print("\nOxygen levels are within safe limits")
                                    break
                                elif values[0] < 19.5:
                                    print("\nOxygen levels are critically low, please report to deck immediately")
                                    break
                                elif values[0] > 23.5:
                                    print(
                                        "\nOxygen levels are high, risk of fire hazard and hyperoxia, please report "
                                        "to deck immediately")
                                    break
                                else:
                                    print("\nThere has been an error in the system, please review sensor data")
                                    break
                        elif selection2 == 2:
                            while True:
                                if 17 <= values[1] <= 28:
                                    print("\nCabin temperature is within safe limits")
                                    break
                                elif values[1] < 17:
                                    print("\nCabin temperature low...")
                                    choice3 = input("\nWould you like to turn the heating on? 'Yes' or 'No': ")
                                    self.reset_alarm()
                                    if choice3.lower() == "yes":
                                        print("\nHeating deck...")
                                        break
                                    else:
                                        print("\nNo action taken")
                                        break
                                elif values[1] > 28:
                                    while True:
                                        print("\nCabin temperature is warm, please select from the following options: ")
                                        choice3 = input(
                                            "\n1. Begin heat release into the atmosphere\n2. No action\n3. Turn heating on")
                                        self.reset_alarm()
                                        if choice3 == "1":
                                            print("\nHeat exchange initialised... temperature dropping")
                                            break
                                        elif choice3 == "2":
                                            break
                                        elif choice3 == "3":
                                            print("\nTurning heating on... temperature raising")
                                            break
                                        else:
                                            print("\nChoice not valid.")
                        elif selection2 == 3:
                            while True:
                                if 10.1 <= values[2] <= 20:
                                    print("\nCabin pressure is within normal levels")
                                    break
                                elif values[2] < 10.1:
                                    print(
                                        "\nCabin pressure extremely low, high hipoxia risk, please report to deck immediately")
                                    break
                                elif values[2] > 20:
                                    print("\nCabin pressure levels are high, please select one of this options: ")
                                    choice3 = input("\n1. Open pressure relief valve\n2. No action\n")
                                    self.reset_alarm()
                                    if choice3 == "1":
                                        print("\nOpening pressure relief valve, stabilising pressure...")
                                        break
                                    elif choice3 == "2":
                                        print("\nIgnoring warning...")
                                        break
                                    else:
                                        print("\nInvalid option")
                        elif selection2 == 4:
                            print("Returning to main menu")
                            break
                        else:
                            print("Please enter a number from 1-4")
                elif selection1 == 3:
                    while True:
                        method = input("\nWould you like to get all logons or filter them by user? Enter 'all' or 'username': ")
                        self.reset_alarm()
                        if method == "all":
                            self.api.get_logons("all")
                            break
                        elif method == "username":
                            username = input("\nWhat user would you like to filter for?: ")
                            self.api.get_logons("username", username=username)
                            break
                        else:
                            print("\nInvalid input.")
                            break
                elif selection1 == 4:
                    print("\nThanks for using the ISS Bulwark Systems APP")
                    sys.exit(0)
                else:
                    print("Your selection was out of range.")
            except ValueError:
                print("Please enter numerical input.")
