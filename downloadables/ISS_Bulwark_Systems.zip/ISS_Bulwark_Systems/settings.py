# ------------SETTINGS------------#

class Main:
    def __init__(self, security, accountType, username,timeout=300):
        """
        :param timeout in SECS
        """
        self.security = security
        self.accountType = accountType
        self.username = username
        self.timeout = timeout

    def __repr__(self):
        return f"SettingsFile Main(security = {self.security}, accountType = {self.accountType}, username = {self.username})"

# -----------END OF SETTINGS---------#

