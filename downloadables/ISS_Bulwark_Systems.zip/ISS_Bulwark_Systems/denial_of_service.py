from locust import HttpUser, between, task
from multiprocessing import Value

# -------GLOBAL VARIABLES---------#

dummy_number = Value('i', 0)


# -----COMMAND TO RUN------#

# locust -f denial_of_service.py --processes -1

class ServerUser(HttpUser):
    host = "http://127.0.0.1:5001"
    wait_time = between(2, 5)

    # Define a GET request for the standard user miguelon
    @task
    def user_locator(self):
        self.client.get("/users/username?value=miguelon")

    # Define a POST request, this one will populate dummy users. It is a dangerous command, it can seriously damage
    # the database
    @task
    def user_creator(self):
        global dummy_number
        with dummy_number.get_lock():  # Ensure atomic increment
            post_dict = {
                "username": f"DummyUser{dummy_number.value}",
                "name": "Dummy",
                "salt": "randomsalt",
                "password": "thisisadummypassword",
                "accountType": "user"
            }
            self.client.post("/add/user", json=post_dict)
            dummy_number.value += 1


